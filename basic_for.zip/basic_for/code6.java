class F{
        public static void main(String[] args){
                for(int i=80;i>=10;i--){
                        System.out.println(i);
                }
        }
}
