class H{
        public static void main(String[] args){
		int num = 14;
                for(int i=10;i>=1;i--){
                        System.out.println(num*i);
                }
        }
}
