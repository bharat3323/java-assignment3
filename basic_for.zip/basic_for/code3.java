class C{
        public static void main(String[] args){
                for(int i=100;i<110;i++){
                        System.out.println(i);
                }
        }
}
